# Dulce Galletas - Sitio Web

Esta es la versión de sitio web normal de Dulce Galletas, no app.

## Archivos

- docs/index.html

## Para publicar en GitHub Pages

1. Sube el contenido de la carpeta `docs/` a la carpeta `docs/` del repositorio.
2. En GitHub entra a Settings > Pages.
3. Configura:
   - Branch: main
   - Folder: /docs
4. Guarda.

Enlace esperado:

https://eliax247.github.io/Dulce-galletas/

## Importante

Cambia el WhatsApp de ejemplo dentro de `index.html` por el número real del negocio.
